#include<stdio.h>
#include<stdlib.h>
#include <ctype.h>
#define N 50

void empiler(int n);
void depiler(int* n);
int trans(char n);