#define N 50
#include<stdio.h>




void ajouter(int n);
void retirer(int* n);
void get(int *a,int *b);